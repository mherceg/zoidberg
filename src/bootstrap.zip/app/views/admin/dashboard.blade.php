@extends('admin.main')


@section('body')
<h1>hello</h1>
@stop


@section('nav-top')
	@include('admin.nav-top')
@stop


@section('nav-sidebar')
	@include('admin.nav-left')
@stop