<?php

class DocumentController extends BaseController {

	private $passed_data = array();

    public function retrivePageTitle() {
        return "Datoteke";
    }

}
