<?php

class Tipovi extends Eloquent {
	protected $table = 'tipovi';
	public $timestamps = false;

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	//protected $hidden = array('password', 'remember_token');
	public function svi_clanovi()
	{
		return $this->hasMany('User', 'tip');
	}
}