#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>

int brojOkvira, brojZahtjeva;
int zahtjevi[20];
int okviri[10];
int moguciZahjevi[10];
int trenutniZahtjev = 0;
int zamjenjeniOkvir = 0;
int flag = 0;
int moze = 0;

void Generator(void *p) {
	int i, j;
	
	for(i = 0; i < brojZahtjeva; ++i) {
		zahtjevi[i] = rand() % 10;
	}
	moze = 1;
	
	for(i = 0; i < brojZahtjeva; ++i) {
		sleep(1);
		zahtjevi[brojZahtjeva+i] = rand() % 10;
	}
}

void PrintStanje() {
	int i;
	
	for(i = 0; i < brojZahtjeva; ++i) {
		if(i+trenutniZahtjev >= 20 || zahtjevi[i+trenutniZahtjev] == -1) printf("-");
		else printf("%d", zahtjevi[i+trenutniZahtjev]);
		if(i + 1 != brojZahtjeva) printf(",");
	}
	printf("\t");
	printf("%d", zahtjevi[trenutniZahtjev]);
	printf("\t");
	
	for(i = 0; i < brojOkvira; ++i) {
		if(i == zamjenjeniOkvir) {
			printf("[%d]", okviri[i]);
		}
		else {
			if(okviri[i] == -1) printf("-");
			else printf("%d", okviri[i]);
		}
		printf("\t");
	}
	if(flag) printf("\t #POGODAK");

	printf("\n");
}

void Obrada() {
	int i, j, k, flag2 = 0;
	while(!moze);
	
	for(i = 0; i < brojZahtjeva*2; ++i) {
		for(j = 0; j < brojOkvira; ++j) {
			if(okviri[j] == zahtjevi[trenutniZahtjev]) {
				zamjenjeniOkvir = -1;
				flag = 1;
				moguciZahjevi[zahtjevi[trenutniZahtjev]] = i;
				break;
			}
		}
		
		if(!flag) {
			for(k = 0; k < brojOkvira; ++k) {
				if(okviri[k] == -1) {
					okviri[k] = zahtjevi[trenutniZahtjev];
					zamjenjeniOkvir = k;
					moguciZahjevi[zahtjevi[trenutniZahtjev]] = i;
					flag2 = 1;
					break;
				} 
			}
			
			if(!flag2) {
				int zamjenjiv = 0;
				
				for(k = 1; k < brojOkvira; ++k) {
					if(moguciZahjevi[okviri[k]] < moguciZahjevi[okviri[zamjenjiv]]) zamjenjiv = k;
				}
				
				zamjenjeniOkvir = zamjenjiv;
				okviri[zamjenjeniOkvir] = zahtjevi[trenutniZahtjev]; 
				moguciZahjevi[zahtjevi[trenutniZahtjev]] = i;
			}
		}
		
		PrintStanje();
		++trenutniZahtjev;
		flag = 0;
		flag2 = 0;
		sleep(1);
	}
}

int main(int argc, char **argv) {
	int i;
	pthread_t gener;
	
	if(argc == 3) {
		brojOkvira = atoi(argv[1]);
		brojZahtjeva = atoi(argv[2]);
	}
	else {
		printf("Nedovoljno arugmenata\n");
		return -1;
	}
	
	srand(time(NULL));
	
	for(i = 0; i < 20; ++i) {
		zahtjevi[i] = -1;
		if(i < 10) okviri[i] = -1;
	}
	
	printf("Zahtjevi");
	
	for(i = 0; i < brojZahtjeva/5; ++i) printf("\t");
	printf("N\t");
	for(i = 0; i < brojOkvira; ++i) {
		printf("%d\t", i+1);
	}
	printf("\n");
	for(i = 0; i < brojOkvira; ++i) {
		printf("------------");
	}
	printf("------------------\n");
	
	if(pthread_create(&gener, NULL, (void*)Generator, NULL)) {
			perror("pthread_create");
			exit(-1);
	}
	
	Obrada();
	pthread_join(gener, NULL);
	
	return 0;
}
