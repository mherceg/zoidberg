#include <cstdio>
#include <set>
#include <vector>
using namespace std;

class Zaglavlje {
public:
	int pocetak;
	int velicina;
	bool jeSlobodan;

	Zaglavlje() {}
	Zaglavlje(int setP, int setV, bool setS) {
		pocetak = setP;
		velicina = setV;
		jeSlobodan = setS;
	}

	bool operator< (const Zaglavlje &A) const {
		return this->pocetak < A.pocetak;
	}
};

set<Zaglavlje> spremnik;
set<int> slobodniBlokovi;
int broj_blokova = 0, slobodni = 0, zauzeti = 0;

void PopraviBlokove() {
	set<Zaglavlje>::iterator iter, iter2;
	bool bugflag = false;

	for(iter = spremnik.begin(); iter != spremnik.end(); ++iter) {
		if(bugflag) {
			iter = spremnik.begin();
			bugflag = false;
		}
		iter++;
		iter2 = iter;
		if(iter2 == spremnik.end()) break;
		--iter;
	
		if(iter->jeSlobodan && iter2->jeSlobodan) {
			Zaglavlje temp(iter->pocetak, iter->velicina + iter2->velicina, 1);
			
			slobodniBlokovi.erase(iter->velicina);
			spremnik.erase(iter);
			--slobodni;
			
			slobodniBlokovi.erase(iter2->velicina);
			spremnik.erase(iter2);
			--slobodni;
			
			spremnik.insert(temp);
			++slobodni;
			slobodniBlokovi.insert(temp.velicina);
			bugflag = true;
			iter = spremnik.begin();
		}
	}
}

void IspisListe() {
	int i = 1;
	for(set<Zaglavlje>::iterator it = spremnik.begin(); it != spremnik.end(); ++it) {
		printf("%d: pocetak = %d, velicina = %d, oznaka = %c\n", i, it->pocetak, it->velicina, (it->jeSlobodan) ? 's' : 'z');
		++i;
	}
}

int dodijeli(unsigned velicina) {
	velicina += sizeof(Zaglavlje);
	int velicinaBloka = 0, ret = -1;
	
	if(slobodniBlokovi.rbegin() == slobodniBlokovi.rend()) return -1;
	else velicinaBloka = *(slobodniBlokovi.rbegin());
	if(velicina > velicinaBloka || slobodni == 0) return -1;

	for(set<int>::reverse_iterator it = slobodniBlokovi.rbegin(); it != slobodniBlokovi.rend(); ++it) {
		velicinaBloka = *it;
		if(velicinaBloka < velicina) {
			it--;
			velicinaBloka = *it;
			break;
		}
	}

	if(velicinaBloka - velicina <= sizeof(Zaglavlje)) velicina = velicinaBloka;
	Zaglavlje novo(-3, velicina, 0);
	++zauzeti;
	slobodniBlokovi.erase(velicinaBloka);
	--slobodni;

	for(set<Zaglavlje>::iterator it = spremnik.begin(); it != spremnik.end(); ++it) {
		if(it->velicina == velicinaBloka) {
			ret = novo.pocetak = it->pocetak;

			spremnik.erase(it);
			spremnik.insert(novo);

			if(velicinaBloka - velicina > 0) {
				Zaglavlje noviPrazni(novo.pocetak + novo.velicina + 1, velicinaBloka-velicina, 1);
				slobodniBlokovi.insert(velicinaBloka-velicina);
				++slobodni;
				spremnik.insert(noviPrazni);
			}
			break;
		}
	}

	return ret;
}

void oslobodi(int pozicija) {
	for(set<Zaglavlje>::iterator it = spremnik.begin(); it != spremnik.end(); ++it) {
		if(it->pocetak == pozicija && !it->jeSlobodan) {
			Zaglavlje q(it->pocetak, it->velicina, true);
			spremnik.erase(it);
			spremnik.insert(q);
			slobodniBlokovi.insert(q.velicina);
			++slobodni;
			--zauzeti;
			break;
		}
	}
	PopraviBlokove();
}

int main( void ) {
	int buff, vel_zahtjev;
	slobodniBlokovi.insert(10000);
	++slobodni;
	spremnik.insert(Zaglavlje(0, 10000, 1));

	do {
		printf("broj blokova = %d, slobodni = %d, zauzeti = %d\n", slobodni+zauzeti, slobodni, zauzeti);
		IspisListe();
		printf("Unesi zahtjev (1 - dodijeli, 2 - oslobodi, -1 - ugasi): ");
		scanf("%d", &buff);

		switch(buff) {
		case 1:
			printf("Unesi kolicinu: ");
			scanf("%d", &vel_zahtjev);
			printf("Dodijeljen blok na adresi %d\n", dodijeli(vel_zahtjev));
			break;

		case 2:
			printf("Unesi adresu: ");
			scanf("%d", &vel_zahtjev);
			oslobodi(vel_zahtjev);
			
			break;

		default: break;
		}
		printf("\n");
	} while(buff != -1);

	return 0;
}
